<?php 


// data from the registation form of index.php

if(isset($_POST['register'])) {



//create connection 
$conn=new mysqli("localhost","root","","shopnepal");
//if connection error occured
if($conn->connect_error){
  die ("connection failed").$conn->connect-error;
}



$name=$_POST['name'];
$email=$_POST['email'];
$phone=$_POST['phone'];
$address=$_POST['address'];
$gender=$_POST['gender'];
$dob=$_POST['dob'];
$credit=$_POST['credit'];
$password=$_POST['password'];



//sql query to insert the data into database




$to      = $email; // Send email to our user
$subject = 'Signup | Verification'; // Give the email a subject 
$message = 'this is verification message this  email is used to register the shopnepal website please provied the code we provided happy shoppping '; // Our message above including the link
                     
$headers = 'From:shankarghimire8766@gmail.com' . "\r\n"; // Set from headers


if(mail($email, $subject, $message, $headers)){

echo "email sent sucessfully";

} // Send our email

else{
	echo "email not sent";
}
echo "verified sucessfully";


$sql ="INSERT INTO `member` (`name`, `email`, `phone`, `address`, `gender`, `dob`, `credit`, `password`, `memberid`) VALUES ('$name', '$email', '$phone', '$address', '$gender', '$dob', '$credit', '$password', NULL);";


if ($conn->query($sql) === TRUE) {

    echo "New records created successfully";
    echo '<script type="text/javascript"> alert(" your registation complete")</script>';
   // header('Location:index.php');
    exit;
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();

}




 ?>

<!doctype html>
<html>
	<head>
		<title>registration sucessful</title>
	</head> 
	<body>
		
		<h2>data added sucessfully</h2>

		<div class="data">

	<?php		
			echo $name."<br>";
			echo $email."<br>"; 
			echo $phone."<br>";  


?>
			 

		</div> <!-- end of data -->
	</body>
</html>

