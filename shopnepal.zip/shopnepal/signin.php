<?php

if(isset($_POST['submit'])) {

echo $_POST['submit'];


//create connection 
$conn=new mysqli("localhost","root","","shopnepal");
//if connection error occured
if($conn->connect_error){
  die ("connection failed").$conn->connect-error;
}


$username=$_POST['username'];
$userpassword=$_POST['userpassword'];
echo $username;
echo $userpassword;

//sql statement 
$sql ="SELECT name password From member WHERE name='$username' AND password='$userpassword';";

//executin sql query statemnt 
$result=$conn->query($sql);
echo "query executed";
//fetch row 
$row = mysqli_fetch_row($result);


//checking whether result is null or not 
if (is_null($row)) {
	 echo "sign in unsucessful";
	 }
	 else{
	 	echo "query executed sucessfully";
	 	header('Location:index.php');
	 	

	 }
}
?>


<!doctype html>
<html>	

<head>
	<title>signin </title>
</head>
<body>
	<p>login sucessful!</p>

</body>
</html>