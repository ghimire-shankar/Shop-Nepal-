<?php 


//create connection 
$conn=new mysqli("localhost","root","","shopnepal");
//if connection error occured
if($conn->connect_error){
  die ("connection failed").$conn->connect-error;
}


 ?>